/* Driver support */
void init_driver(mode_t mode, int maxsize, double sumProbability, bool insertOnly);
void free_driver();
void drive();
