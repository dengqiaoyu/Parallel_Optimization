extern const char *job_names[];

void report_job(int benchmark, int msecs);

void report(int nthreads, double secs);
