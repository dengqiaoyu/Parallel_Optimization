// External declarations
void run(int nthreads);
extern int job_count[];
extern int job_limit[];
