// Benchmark IDs

#define BENCH_WISDOM 0
#define BENCH_PRIMES 1
#define BENCH_TELLME 2
#define BENCH_PROJECT 3
#define BENCH_END 4

void execute_work(int b);
