CMU 15418 Assignment 1: Analyzing Program Performance on a Multi-Core CPU
=========================================================================

Please refer to the [course website](http://15418.courses.cs.cmu.edu/spring2016/article/3) for instructions.
