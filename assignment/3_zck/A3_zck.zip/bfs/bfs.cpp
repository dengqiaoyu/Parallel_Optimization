#include "bfs.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cstddef>
#include <omp.h>
#include <iostream>

#include "../common/CycleTimer.h"
#include "../common/graph.h"

#define ROOT_NODE_ID 0
#define NOT_VISITED_MARKER -1

// #define VERBOSE 

#define chunksize 1000
#define bu_flag 1
#define td_flag 1
#define batch_size 10000

void vertex_set_clear(vertex_set* list) {
    list->count = 0;
}

void vertex_set_init(vertex_set* list, int count) {
    list->max_vertices = count;
    list->vertices = (int*)malloc(sizeof(int) * list->max_vertices);
    vertex_set_clear(list);
}

// Take one step of "top-down" BFS.  For each vertex on the frontier,
// follow all outgoing edges, and add all neighboring vertices to the
// new_frontier.
void top_down_step(
    Graph g,
    vertex_set* frontier,
    vertex_set* new_frontier,
    int* distances)
{
#pragma omp parallel if (td_flag)
    {
        int cu_batch_new = 0;
        // vertex_set* frontier_private;
        vertex_set list3;
        vertex_set_init(&list3, g->num_nodes);
        vertex_set* new_frontier_private = &list3;
        

        for (int cu_batch=0; cu_batch<frontier->count; cu_batch+=batch_size){
            cu_batch_new = std::min(cu_batch + batch_size, frontier->count);
            
            #pragma omp for schedule(dynamic, batch_size/100) nowait
            for (int i=cu_batch; i<cu_batch_new; i++) {

                int node = frontier->vertices[i];

                int start_edge = g->outgoing_starts[node];
                int end_edge = (node == g->num_nodes - 1)
                                   ? g->num_edges
                                   : g->outgoing_starts[node + 1];

                // attempt to add all neighbors to the new frontier
                for (int neighbor=start_edge; neighbor<end_edge; neighbor++) {
                    int outgoing = g->outgoing_edges[neighbor];

                    if (distances[outgoing] == NOT_VISITED_MARKER) {
                        __sync_bool_compare_and_swap(distances + outgoing, distances[outgoing], distances[node] + 1);
                        int index = new_frontier_private->count++;
                        new_frontier_private->vertices[index] = outgoing;
                        // #pragma omp critical
                        // {
                        //     distances[outgoing] = distances[node] + 1;
                        //     int index = new_frontier->count++;
                        //     new_frontier->vertices[index] = outgoing;
                        // }
                    }
                }
            }
        }

    #pragma omp critical  // [?] opt, debug, still need improvement
        {
            int start = new_frontier->count;
            new_frontier->count += new_frontier_private->count;
            for (int index=0; index<new_frontier_private->count; index++){
                new_frontier->vertices[start + index] = new_frontier_private->vertices[index]; 
            }
        }

        vertex_set_clear(new_frontier_private);       
    }


}

// Implements top-down BFS.
//
// Result of execution is that, for each node in the graph, the
// distance to the root is stored in sol.distances.
void bfs_top_down(Graph graph, solution* sol) {

    vertex_set list1;
    vertex_set list2;
    vertex_set_init(&list1, graph->num_nodes);
    vertex_set_init(&list2, graph->num_nodes);

    vertex_set* frontier = &list1;
    vertex_set* new_frontier = &list2;

    // initialize all nodes to NOT_VISITED
    for (int i=0; i<graph->num_nodes; i++)
        sol->distances[i] = NOT_VISITED_MARKER;

    // setup frontier with the root node
    frontier->vertices[frontier->count++] = ROOT_NODE_ID;
    sol->distances[ROOT_NODE_ID] = 0;

    while (frontier->count != 0) {

#ifdef VERBOSE
        double start_time = CycleTimer::currentSeconds();
#endif

        vertex_set_clear(new_frontier);

        top_down_step(graph, frontier, new_frontier, sol->distances);

#ifdef VERBOSE
    double end_time = CycleTimer::currentSeconds();
    printf("frontier=%-10d %.4f sec\n", frontier->count, end_time - start_time);
#endif

        // swap pointers
        vertex_set* tmp = frontier;
        frontier = new_frontier;
        new_frontier = tmp;
    }
}

void bottom_up_step(
    Graph g,
    vertex_set* frontier,
    vertex_set* new_frontier,
    int* distances,
    int* distances_new)
{ 
#pragma omp parallel if (bu_flag)
    {    
        vertex_set list3;
        vertex_set_init(&list3, g->num_nodes);
        vertex_set* new_frontier_private = &list3;

    #pragma omp for schedule(dynamic, chunksize) nowait
        for (int node=0; node<num_nodes(g); node++) {

    #ifdef VERBOSE
        if (node==0) printf("Num_threads=%d\n", omp_get_num_threads());
    #endif
            if (distances[node] == NOT_VISITED_MARKER){
                const Vertex* start = incoming_begin(g, node);
                const Vertex* end = incoming_end(g, node);
                for (const Vertex* j=start; j<end; j++){
                    if (distances[*j] != NOT_VISITED_MARKER){
                        // Temporary storation for new distances before next round
                        distances_new[node] = distances[*j] + 1;
                        // [?] opt for parallel
                        // #pragma omp critical
                        // {
                        //     int index = new_frontier->count++;
                        //     new_frontier->vertices[index] = node;
                        // }                    
                        // break;
                        {
                            int index = new_frontier_private->count++;
                            new_frontier_private->vertices[index] = node;
                        }                    
                        break;

                    }
                }
            }
        }


    #pragma omp critical  // [?] opt, debug, still need improvement
        {
            int start = new_frontier->count;
            new_frontier->count += new_frontier_private->count;
            for (int index=0; index<new_frontier_private->count; index++){
                new_frontier->vertices[start + index] = new_frontier_private->vertices[index]; 
            }
        }

        vertex_set_clear(new_frontier_private);       
    
    #pragma omp barrier

    #pragma omp for schedule(static, chunksize/10)
    // #ifdef VERBOSE
    //     printf("Num_threads=%d\n", omp_get_num_threads());
    // #endif
        for (int index=0; index<new_frontier->count; index++){
            int node = new_frontier->vertices[index];
            distances[node] = distances_new[node];
        }
    }
}


void bfs_bottom_up(Graph graph, solution* sol)
{
    vertex_set list1;
    vertex_set list2;
    vertex_index_set list4;
    vertex_set_init(&list1, graph->num_nodes);
    vertex_set_init(&list2, graph->num_nodes);
    vertex_set_init(&list4, graph->num_nodes);

    vertex_set* frontier = &list1;
    vertex_set* new_frontier = &list2;
    vertex_index_set* unvisited_vertex = &list4;

    int* distances_new;
    distances_new = (int*)malloc(sizeof(int) * graph->num_nodes);

    // initialize all nodes to NOT_VISITED
    for (int i=0; i<graph->num_nodes; i++)
        sol->distances[i] = NOT_VISITED_MARKER;

    // setup frontier with the root node
    frontier->vertices[frontier->count++] = ROOT_NODE_ID;
    sol->distances[ROOT_NODE_ID] = 0;
    distances_new[ROOT_NODE_ID] = 0;

    while (frontier->count != 0) {

#ifdef VERBOSE
        double start_time = CycleTimer::currentSeconds();
#endif

        vertex_set_clear(new_frontier);

        bottom_up_step(graph, frontier, new_frontier, sol->distances, distances_new);

#ifdef VERBOSE
    double end_time = CycleTimer::currentSeconds();
    printf("frontier=%-10d %.4f sec\n", frontier->count, end_time - start_time);
#endif

        // swap pointers
        vertex_set* tmp = frontier;
        frontier = new_frontier;
        new_frontier = tmp;
    }

    // 15-418/618 students:
    //
    // You will need to implement the "bottom up" BFS here as
    // described in the handout.
    //
    // As a result of your code's execution, sol.distances should be
    // correctly populated for all nodes in the graph.
    //
    // As was done in the top-down case, you may wish to organize your
    // code by creating subroutine bottom_up_step() that is called in
    // each step of the BFS process.
}

void bfs_hybrid(Graph graph, solution* sol)
{

    /*
    1. Opt Bottom-Up for largest frontier
    2. Opt Top-Down for relatively smaller frontier
    */
    vertex_set list1;
    vertex_set list2;
    vertex_set_init(&list1, graph->num_nodes);
    vertex_set_init(&list2, graph->num_nodes);

    vertex_set* frontier = &list1;
    vertex_set* new_frontier = &list2;

    int* distances_new;
    distances_new = (int*)malloc(sizeof(int) * graph->num_nodes);



    // initialize all nodes to NOT_VISITED
    for (int i=0; i<graph->num_nodes; i++)
        sol->distances[i] = NOT_VISITED_MARKER;

    // setup frontier with the root node
    frontier->vertices[frontier->count++] = ROOT_NODE_ID;
    sol->distances[ROOT_NODE_ID] = 0;
    distances_new[ROOT_NODE_ID] = 0;

    while (frontier->count != 0) {

#ifdef VERBOSE
        double start_time = CycleTimer::currentSeconds();
#endif

        vertex_set_clear(new_frontier);
        if (frontier->count > 900000) bottom_up_step(graph, frontier, new_frontier, sol->distances, distances_new);
        else top_down_step(graph, frontier, new_frontier, sol->distances);

#ifdef VERBOSE
    double end_time = CycleTimer::currentSeconds();
    printf("frontier=%-10d %.4f sec\n", frontier->count, end_time - start_time);
#endif

        // swap pointers
        vertex_set* tmp = frontier;
        frontier = new_frontier;
        new_frontier = tmp;
    }
}



/*
V1.0
1. critical -> lock
2. save some var -> local
3. how to dynamically decide to use top/bottom?
4. change unvisited nodes represenation

top-down  -> compare&swap [Y]
bottom-up -> change unvisited nodes representation way  


V2.0
1. divide into parts but have to sort now???  seems not to improve
*/





