#include "page_rank.h"

#include <stdlib.h>
#include <cmath>
#include <omp.h>
#include <utility>

#include "../common/CycleTimer.h"
#include "../common/graph.h"


// pageRank --
//
// g:           graph to process (see common/graph.h)
// solution:    array of per-vertex vertex scores (length of array is num_nodes(g))
// damping:     page-rank algorithm's damping parameter
// convergence: page-rank algorithm's convergence threshold
//
void pageRank(Graph g, double* solution, double damping, double convergence)
{

  // initialize vertex weights to uniform probability. Double
  // precision scores are used to avoid underflow for large graphs

  // 1. Computation 2.Parallel, barrier  3.critical + cache 

  int numNodes = num_nodes(g);
  bool converged = 0; 


  double equal_prob = 1.0 / numNodes;
  int chunksize = 5000;

  double* solution_old;
  solution_old = (double*)malloc(sizeof(double) * g->num_nodes);

  int nooutnode_end = 0;
  int* nooutnodes;
  nooutnodes = (int*)malloc(sizeof(int) * g->num_nodes);
  double* mean_edge_pr;
  mean_edge_pr = (double*)malloc(sizeof(double) * g->num_nodes);


  // Initialization
  #pragma omp parallel for schedule(static, chunksize)
  for (int i = 0; i < numNodes; ++i) {
    solution[i] = equal_prob;
  }

  // Find all nodes without out-going edges
  // #pragma omp parallel for schedule(dynamic, chunksize)
  for (int i = 0; i < numNodes; ++i) {
    if (outgoing_size(g, i) == 0){
      nooutnodes[nooutnode_end] = i;
      nooutnode_end ++;
    }
  }



  while (!converged) {

    // Cal mean pr value of outgoing nodes for each node

    #pragma omp parallel for schedule(dynamic, chunksize)
    for (int i = 0; i < numNodes; ++i) {
      if (outgoing_size(g, i) == 0) mean_edge_pr[i] = 0.0;
      else mean_edge_pr[i] = solution[i] / outgoing_size(g, i);  
    }

    double sum_nooutnode_pr = 0.0;

    #pragma omp parallel for reduction(+:sum_nooutnode_pr) schedule(dynamic, chunksize)
    for (int node = 0; node < nooutnode_end; ++node) {
      sum_nooutnode_pr += solution[nooutnodes[node]];
    }
    sum_nooutnode_pr /= numNodes;

    double diff = 0.0;
    // Loop all incoming edge 
    #pragma omp parallel for schedule(dynamic,chunksize)
    for (int i=0; i < numNodes; ++i){
      double solution_new_unit = 0.0;
      if (incoming_size(g, i) > 0){
        const Vertex* start = incoming_begin(g, i);
        const Vertex* end = incoming_end(g, i);
        
        // [DEBUG] node
        for (const Vertex* node = start; node < end; ++node) {
          solution_new_unit += mean_edge_pr[*node];
        }           
      }
      
      solution_new_unit = (solution_new_unit + sum_nooutnode_pr) * damping + (1.0 - damping) / numNodes;

      solution_old[i] = solution[i];
      solution[i] = solution_new_unit;
    } 

    // Outside loop
    #pragma omp parallel for reduction(+:diff)
    for (int i = 0; i < numNodes; ++i) {
      diff += fabs(solution_old[i] - solution[i]);
    }

    converged = (diff < convergence);
  }
}

//    // 418/618 Students: Implement the page rank algorithm here.  You
//    //   are expected to parallelize the algorithm using openMP.  Your
//    //   solution may need to allocate (and free) temporary arrays.

//    //   Basic page rank pseudocode:

//      // initialization: see example code above
//     score_old[vi] = 1/numNodes;


    
//     while (!converged) {

//        // compute score_new[vi] for all nodes vi:
//        score_new[vi] = sum over all nodes vj reachable from incoming edges
//                           { score_old[vj] / number of edges leaving vj  }
//        score_new[vi] = (damping * score_new[vi]) + (1.0-damping) / numNodes;




//        // Add a fraction of the leftover mass from all nodes with no outgoing
//        // edges onto this node
//        score_new[vi] += sum over all nodes vj with no outgoing edges
//                           { damping * score_old[vj] / numNodes }

//        // compute how much per-node scores have changed
//        // quit once algorithm has converged

//        global_diff = sum over all nodes vi { abs(score_new[vi] - score_old[vi]) };
//        converged = (global_diff < con
//         vergence)
//      }

   
// }
